var protocol_a_map_location_manager_delegate_01_p =
[
    [ "amapLocationManager:didChangeAuthorizationStatus:", "protocol_a_map_location_manager_delegate_01-p.html#ac9ce3b0c38e08ef4fd9cffd9dd4d01bd", null ],
    [ "amapLocationManager:didDetermineState:forRegion:", "protocol_a_map_location_manager_delegate_01-p.html#abc2952998a7313e43c95ee74cb00a2db", null ],
    [ "amapLocationManager:didEnterRegion:", "protocol_a_map_location_manager_delegate_01-p.html#a5deb369b06d137428b1c810f4a3bb292", null ],
    [ "amapLocationManager:didExitRegion:", "protocol_a_map_location_manager_delegate_01-p.html#a838f495edf8ec1a7f962db9e56078ee0", null ],
    [ "amapLocationManager:didFailWithError:", "protocol_a_map_location_manager_delegate_01-p.html#a6c84396a5b2d5216be5f5a65b369abe2", null ],
    [ "amapLocationManager:didStartMonitoringForRegion:", "protocol_a_map_location_manager_delegate_01-p.html#acc3ba84adea882f475e4c2b664fd3aaf", null ],
    [ "amapLocationManager:didUpdateLocation:", "protocol_a_map_location_manager_delegate_01-p.html#a314c13ad02f2d4b5e5230d897d282e55", null ],
    [ "amapLocationManager:didUpdateLocation:reGeocode:", "protocol_a_map_location_manager_delegate_01-p.html#ab20f5e1f59c242ad5f53efe7099f1653", null ],
    [ "amapLocationManager:monitoringDidFailForRegion:withError:", "protocol_a_map_location_manager_delegate_01-p.html#ae3c34533462fd49e40232cb5d22781ed", null ]
];
var interface_a_map_geo_fence_polygon_region =
[
    [ "coordinates", "interface_a_map_geo_fence_polygon_region.html#a490bbca5478c20aebbbe5983a76428bf", null ],
    [ "count", "interface_a_map_geo_fence_polygon_region.html#a8bddaff79c015f80a1df147f250fa25c", null ]
];
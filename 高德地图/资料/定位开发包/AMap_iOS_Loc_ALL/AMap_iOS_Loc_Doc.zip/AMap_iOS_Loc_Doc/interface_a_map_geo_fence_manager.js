var interface_a_map_geo_fence_manager =
[
    [ "addAroundPOIRegionForMonitoringWithLocationPoint:aroundRadius:keyword:POIType:size:customID:", "interface_a_map_geo_fence_manager.html#a12bc5df240f526ca68e0d77d91a6f945", null ],
    [ "addCircleRegionForMonitoringWithCenter:radius:customID:", "interface_a_map_geo_fence_manager.html#a76a6022f662359a18962fa6ec84c9aa0", null ],
    [ "addDistrictRegionForMonitoringWithDistrictName:customID:", "interface_a_map_geo_fence_manager.html#a7ed8338510d9267b3ab7554e398da75c", null ],
    [ "addKeywordPOIRegionForMonitoringWithKeyword:POIType:city:size:customID:", "interface_a_map_geo_fence_manager.html#a4f8d4b129d8a4698adc34fd4a4da46ed", null ],
    [ "addPolygonRegionForMonitoringWithCoordinates:count:customID:", "interface_a_map_geo_fence_manager.html#a074ed84bbbdbfce18257e5930bcc8433", null ],
    [ "geoFenceRegionsWithCustomID:", "interface_a_map_geo_fence_manager.html#a4179fc03664811511071c1bbbaf2f646", null ],
    [ "removeAllGeoFenceRegions", "interface_a_map_geo_fence_manager.html#a396e4e7829ede7f648b965eae6a195f5", null ],
    [ "removeGeoFenceRegionsWithCustomID:", "interface_a_map_geo_fence_manager.html#a9d8e4a7ea09af05f01fd177baf9d92cf", null ],
    [ "removeTheGeoFenceRegion:", "interface_a_map_geo_fence_manager.html#ae2ac01c852052be47c3e4621685377cd", null ],
    [ "activeAction", "interface_a_map_geo_fence_manager.html#a83a344ed6328616f13b83e39d25fccd2", null ],
    [ "allowsBackgroundLocationUpdates", "interface_a_map_geo_fence_manager.html#a93afe7a597e6cb2a5dba4f936512cc8d", null ],
    [ "delegate", "interface_a_map_geo_fence_manager.html#aae0e2df8666a610d3e1ee642d6454c1e", null ],
    [ "detectRiskOfFakeLocation", "interface_a_map_geo_fence_manager.html#a426700f38ad3371a9286372e76769416", null ],
    [ "pausesLocationUpdatesAutomatically", "interface_a_map_geo_fence_manager.html#a77f994886c0f70b050371295276e5437", null ]
];
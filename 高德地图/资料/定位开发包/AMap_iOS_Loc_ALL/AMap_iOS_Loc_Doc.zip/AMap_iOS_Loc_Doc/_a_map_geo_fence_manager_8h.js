var _a_map_geo_fence_manager_8h =
[
    [ "AMapGeoFenceManager", "interface_a_map_geo_fence_manager.html", "interface_a_map_geo_fence_manager" ],
    [ "<AMapGeoFenceManagerDelegate >", "protocol_a_map_geo_fence_manager_delegate_01-p.html", "protocol_a_map_geo_fence_manager_delegate_01-p" ],
    [ "AMapGeoFenceActiveAction", "_a_map_geo_fence_manager_8h.html#ad62c58e20df8610a243d895e80e890dd", [
      [ "AMapGeoFenceActiveActionNone", "_a_map_geo_fence_manager_8h.html#ad62c58e20df8610a243d895e80e890dda1ce52d51c1ea2700b3e17a313ec19620", null ],
      [ "AMapGeoFenceActiveActionInside", "_a_map_geo_fence_manager_8h.html#ad62c58e20df8610a243d895e80e890ddab73e3b4c449fe433f75d140b535c5cbd", null ],
      [ "AMapGeoFenceActiveActionOutside", "_a_map_geo_fence_manager_8h.html#ad62c58e20df8610a243d895e80e890dda2fbd1f8a038a9c73d3ef62e5c5d7bb4c", null ],
      [ "AMapGeoFenceActiveActionStayed", "_a_map_geo_fence_manager_8h.html#ad62c58e20df8610a243d895e80e890dda3e9e0f64a0777c7568298a2cb867668c", null ]
    ] ]
];
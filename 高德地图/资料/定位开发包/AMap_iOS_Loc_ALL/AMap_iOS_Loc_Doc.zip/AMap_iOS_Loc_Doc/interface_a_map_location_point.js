var interface_a_map_location_point =
[
    [ "latitude", "interface_a_map_location_point.html#a5766a48f87abb77f5a35e0a62b0e57eb", null ],
    [ "longitude", "interface_a_map_location_point.html#ada01b533aad6c2be6e2d02dce57b7210", null ]
];
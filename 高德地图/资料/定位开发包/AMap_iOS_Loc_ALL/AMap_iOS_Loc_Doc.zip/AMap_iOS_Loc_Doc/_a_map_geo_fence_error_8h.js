var _a_map_geo_fence_error_8h =
[
    [ "AMapGeoFenceErrorCode", "_a_map_geo_fence_error_8h.html#ad994e4dabc6207e4d92f970125058c8d", [
      [ "AMapGeoFenceErrorUnknown", "_a_map_geo_fence_error_8h.html#ad994e4dabc6207e4d92f970125058c8da3ce29980384436cd9deafcc6fd9daaa2", null ],
      [ "AMapGeoFenceErrorInvalidParameter", "_a_map_geo_fence_error_8h.html#ad994e4dabc6207e4d92f970125058c8da2b3aabef98d8a124388c6a7ec455c454", null ],
      [ "AMapGeoFenceErrorFailureConnection", "_a_map_geo_fence_error_8h.html#ad994e4dabc6207e4d92f970125058c8da9390f11a1db52b7d4f75419f4479becd", null ],
      [ "AMapGeoFenceErrorFailureAuth", "_a_map_geo_fence_error_8h.html#ad994e4dabc6207e4d92f970125058c8daa83ef49e4ac7d6c4b38801514292bc7e", null ],
      [ "AMapGeoFenceErrorNoValidFence", "_a_map_geo_fence_error_8h.html#ad994e4dabc6207e4d92f970125058c8da6b5bac964f2dbed03ace6633448cbcfc", null ],
      [ "AMapGeoFenceErroFailureLocating", "_a_map_geo_fence_error_8h.html#ad994e4dabc6207e4d92f970125058c8dafc497e132409375440945eb207520f78", null ]
    ] ],
    [ "AMapGeoFenceErrorDomain", "_a_map_geo_fence_error_8h.html#af31f7b2dc7683ba2467cf4cc49e244c7", null ]
];
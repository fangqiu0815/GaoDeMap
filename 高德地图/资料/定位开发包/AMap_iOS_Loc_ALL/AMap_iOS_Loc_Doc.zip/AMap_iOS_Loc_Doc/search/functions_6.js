var searchData=
[
  ['removeallgeofenceregions',['removeAllGeoFenceRegions',['../interface_a_map_geo_fence_manager.html#a396e4e7829ede7f648b965eae6a195f5',1,'AMapGeoFenceManager']]],
  ['removegeofenceregionswithcustomid_3a',['removeGeoFenceRegionsWithCustomID:',['../interface_a_map_geo_fence_manager.html#a9d8e4a7ea09af05f01fd177baf9d92cf',1,'AMapGeoFenceManager']]],
  ['removethegeofenceregion_3a',['removeTheGeoFenceRegion:',['../interface_a_map_geo_fence_manager.html#ae2ac01c852052be47c3e4621685377cd',1,'AMapGeoFenceManager']]],
  ['requestlocationwithregeocode_3acompletionblock_3a',['requestLocationWithReGeocode:completionBlock:',['../interface_a_map_location_manager.html#a37c416c465f6d6919fc86ccfc8c124d3',1,'AMapLocationManager']]],
  ['requeststateforregion_3a',['requestStateForRegion:',['../interface_a_map_location_manager.html#a56d94c7ddab6df68e98aa3fee0429458',1,'AMapLocationManager']]]
];

var protocol_a_map_geo_fence_manager_delegate_01_p =
[
    [ "amapGeoFenceManager:didAddRegionForMonitoringFinished:customID:error:", "protocol_a_map_geo_fence_manager_delegate_01-p.html#aba97aa4477007cf8d2ab7a9ea2960002", null ],
    [ "amapGeoFenceManager:didGeoFencesStatusChangedForRegion:customID:error:", "protocol_a_map_geo_fence_manager_delegate_01-p.html#a420505fa3fb4d6c147315613424ff702", null ]
];
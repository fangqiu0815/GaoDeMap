//
//  APIKey.h
//  OfficialDemoLoc
//
//  Created by AutoNavi on 15-9-14.
//  Copyright (c) 2013年 AutoNavi. All rights reserved.
//

#ifndef OfficialDemoLoc_APIKey_h
#define OfficialDemoLoc_APIKey_h

/* 使用高德地图API，请注册Key，注册地址：http://lbs.amap.com/console/key */

const static NSString *APIKey = @"";

#endif

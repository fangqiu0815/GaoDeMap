//
//  SingleLocaitonAloneViewController.h
//  officialDemoLoc
//
//  Created by 朱浩 on 16/2/24.
//  Copyright © 2016年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapLocationKit/AMapLocationKit.h>

@interface SingleLocaitonAloneViewController : UIViewController

@property (nonatomic, strong) AMapLocationManager *locationManager;

@end

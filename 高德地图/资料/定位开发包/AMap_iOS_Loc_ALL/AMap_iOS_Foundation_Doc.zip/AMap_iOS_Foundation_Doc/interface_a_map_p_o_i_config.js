var interface_a_map_p_o_i_config =
[
    [ "appName", "interface_a_map_p_o_i_config.html#ac4d554c90481d6446b09c88ca6b966e3", null ],
    [ "appScheme", "interface_a_map_p_o_i_config.html#a9cda6dc99eeba47b8017658478e1dbc8", null ],
    [ "keywords", "interface_a_map_p_o_i_config.html#a4a9286b1d2d947c58170c074cb42d496", null ],
    [ "leftTopCoordinate", "interface_a_map_p_o_i_config.html#a23374600d42323635f84f97c6838bd23", null ],
    [ "rightBottomCoordinate", "interface_a_map_p_o_i_config.html#ae32c58f77dcd9b66be27beb5fecc1d0a", null ]
];
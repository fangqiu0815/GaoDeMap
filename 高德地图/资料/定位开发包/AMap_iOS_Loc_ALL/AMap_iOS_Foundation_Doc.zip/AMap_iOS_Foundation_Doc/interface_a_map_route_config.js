var interface_a_map_route_config =
[
    [ "appName", "interface_a_map_route_config.html#a9e8e573a9a4480f99dcdb3a433528079", null ],
    [ "appScheme", "interface_a_map_route_config.html#a61726116c4e7edab9efe08f1bdfb0663", null ],
    [ "destinationCoordinate", "interface_a_map_route_config.html#acfa89a8489de142bec5cc7efae3f38b8", null ],
    [ "drivingStrategy", "interface_a_map_route_config.html#a102a257331bd70803844b85a8b44a1cd", null ],
    [ "routeType", "interface_a_map_route_config.html#adbcc804df0a4e9d6c16a864a67cb82b5", null ],
    [ "startCoordinate", "interface_a_map_route_config.html#a39a29ee37bca9949e6e8ffab78522e40", null ],
    [ "transitStrategy", "interface_a_map_route_config.html#ada61a4ba72df48a9f5279068f3eee1af", null ]
];
var searchData=
[
  ['amapfoundationversionnumber',['AMapFoundationVersionNumber',['../_a_map_foundation_version_8h.html#a1879116222bba8b541eb9437a426f8cb',1,'AMapFoundationVersion.h']]]
];

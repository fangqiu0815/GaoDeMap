var interface_m_a_tile_overlay_renderer =
[
    [ "initWithTileOverlay:", "interface_m_a_tile_overlay_renderer.html#a4b0f24540a961d213026d817334c34ee", null ],
    [ "reloadData", "interface_m_a_tile_overlay_renderer.html#aa7e8ceb17e2af2777441fe7fd3ee0c22", null ],
    [ "tileOverlay", "interface_m_a_tile_overlay_renderer.html#a5fcdcbd7f0a6bb14dcb27249ba6f0edb", null ]
];
var _m_a_pin_annotation_view_8h =
[
    [ "MAPinAnnotationView", "interface_m_a_pin_annotation_view.html", "interface_m_a_pin_annotation_view" ],
    [ "MAPinAnnotationColor", "_m_a_pin_annotation_view_8h.html#acbc6e2cb3e9b02a03d574819291396e0", [
      [ "MAPinAnnotationColorRed", "_m_a_pin_annotation_view_8h.html#acbc6e2cb3e9b02a03d574819291396e0a18e204f3dd28dc2e961668bc295b762c", null ],
      [ "MAPinAnnotationColorGreen", "_m_a_pin_annotation_view_8h.html#acbc6e2cb3e9b02a03d574819291396e0a41d58ac7190e6aea0b7263bca2771261", null ],
      [ "MAPinAnnotationColorPurple", "_m_a_pin_annotation_view_8h.html#acbc6e2cb3e9b02a03d574819291396e0ad4be2003ecb4c9c219be99d441dc432b", null ]
    ] ]
];
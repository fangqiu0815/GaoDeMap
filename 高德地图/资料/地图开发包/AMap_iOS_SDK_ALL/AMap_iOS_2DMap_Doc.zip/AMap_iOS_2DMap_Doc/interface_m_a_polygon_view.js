var interface_m_a_polygon_view =
[
    [ "initWithPolygon:", "interface_m_a_polygon_view.html#af7366dc964ebf62952385118baa5458a", null ],
    [ "polygon", "interface_m_a_polygon_view.html#a0fdbacc7f474ecfa3df30647ef1a272e", null ]
];
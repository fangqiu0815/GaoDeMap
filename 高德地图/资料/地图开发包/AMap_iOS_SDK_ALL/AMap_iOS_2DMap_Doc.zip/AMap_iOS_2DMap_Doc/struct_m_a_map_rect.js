var struct_m_a_map_rect =
[
    [ "origin", "struct_m_a_map_rect.html#a677282a033f0f31cd735c7df97337e3a", null ],
    [ "size", "struct_m_a_map_rect.html#aeaec60bbda1c0da837768ae23afc7a97", null ]
];
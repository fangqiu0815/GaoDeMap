var interface_m_a_multi_point =
[
    [ "getCoordinates:range:", "interface_m_a_multi_point.html#a45f1771301ce12874781a97df7845875", null ],
    [ "pointCount", "interface_m_a_multi_point.html#af7b3e6d897988d9417de41ef5efbfae7", null ],
    [ "points", "interface_m_a_multi_point.html#a20582f70a9e18f21fc2b72aa3fecab5b", null ]
];
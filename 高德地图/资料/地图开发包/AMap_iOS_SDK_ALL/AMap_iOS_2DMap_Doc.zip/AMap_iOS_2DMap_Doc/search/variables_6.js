var searchData=
[
  ['size',['size',['../struct_m_a_map_rect.html#aeaec60bbda1c0da837768ae23afc7a97',1,'MAMapRect']]],
  ['southwest',['southWest',['../struct_m_a_coordinate_bounds.html#af960ce7cd42c367c5a849c00c1cd7909',1,'MACoordinateBounds']]],
  ['span',['span',['../struct_m_a_coordinate_region.html#af63d9832b48a21924c0b9c9ec9e4a38c',1,'MACoordinateRegion']]]
];

var searchData=
[
  ['radius',['radius',['../interface_m_a_circle.html#a818875c0f6ad6fd83d1a805dba15c3d3',1,'MACircle::radius()'],['../interface_m_a_heat_map_tile_overlay.html#a1428aa743b389bcf09dbd9a01c06d7d8',1,'MAHeatMapTileOverlay::radius()']]],
  ['region',['region',['../interface_m_a_map_view.html#ab9db51dfb9a57a9dac7ef756917b0495',1,'MAMapView']]],
  ['reuseidentifier',['reuseIdentifier',['../interface_m_a_annotation_view.html#a322f80fda27f7e0be3fefe1735bf32af',1,'MAAnnotationView']]],
  ['rightcalloutaccessoryview',['rightCalloutAccessoryView',['../interface_m_a_annotation_view.html#a92f39aecf9e98fa9ecfe02c028857b44',1,'MAAnnotationView']]]
];

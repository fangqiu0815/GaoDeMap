var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvwxyz",
  1: "mn",
  2: "m",
  3: "acdefgilmprstuv",
  4: "chlmnoswxyz",
  5: "am",
  6: "m",
  7: "m",
  8: "abcdefghilmoprstuvz",
  9: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Macros"
};


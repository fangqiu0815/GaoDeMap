var searchData=
[
  ['origin',['origin',['../struct_m_a_map_rect.html#a677282a033f0f31cd735c7df97337e3a',1,'MAMapRect']]]
];

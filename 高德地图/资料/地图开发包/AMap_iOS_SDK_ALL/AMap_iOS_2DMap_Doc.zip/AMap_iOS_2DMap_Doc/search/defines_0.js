var searchData=
[
  ['mamapminrequiredfoundationversion',['MAMapMinRequiredFoundationVersion',['../_m_a_map_version_8h.html#a4e506d09ecc84ecbc18bf1cce6b585b2',1,'MAMapVersion.h']]],
  ['mamapversionnumber',['MAMapVersionNumber',['../_m_a_map_version_8h.html#ad1ce79bfa2ff6849f765dc020e10b750',1,'MAMapVersion.h']]]
];

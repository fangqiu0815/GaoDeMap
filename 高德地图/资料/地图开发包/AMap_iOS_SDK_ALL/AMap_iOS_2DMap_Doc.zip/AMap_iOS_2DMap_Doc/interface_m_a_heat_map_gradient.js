var interface_m_a_heat_map_gradient =
[
    [ "initWithColor:andWithStartPoints:", "interface_m_a_heat_map_gradient.html#ade070b227bc5164a1c1f32201b035919", null ],
    [ "colors", "interface_m_a_heat_map_gradient.html#aab25448679ad1e0a685f05b4f7b01654", null ],
    [ "startPoints", "interface_m_a_heat_map_gradient.html#a1de32e7f8c951cbda72c98db61d2a7ef", null ]
];
var interface_m_a_point_annotation =
[
    [ "coordinate", "interface_m_a_point_annotation.html#a537233dd9af6c38478bf748e4abf3a6e", null ],
    [ "lockedScreenPoint", "interface_m_a_point_annotation.html#a754d372e44f27715fd620ed061520eb9", null ],
    [ "lockedToScreen", "interface_m_a_point_annotation.html#ac3d8def7323b7dd2b68c751aba224cd3", null ]
];
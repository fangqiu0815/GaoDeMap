var category_m_a_map_view_07_snapshot_08 =
[
    [ "takeSnapshotInRect:", "category_m_a_map_view_07_snapshot_08.html#a184e6408f2eff4a2f58ea779c63845a2", null ],
    [ "takeSnapshotInRect:withCompletionBlock:", "category_m_a_map_view_07_snapshot_08.html#ac481befe3490bbd4a44800f69e8cb533", null ]
];
var struct_m_a_map_size =
[
    [ "height", "struct_m_a_map_size.html#af5490484d44f5e4e5290fac1ed3c92ac", null ],
    [ "width", "struct_m_a_map_size.html#ab510a37816b8283290450368340906c4", null ]
];
var _m_a_map_view_8h =
[
    [ "MAMapView", "interface_m_a_map_view.html", "interface_m_a_map_view" ],
    [ "MAMapView(Snapshot)", "category_m_a_map_view_07_snapshot_08.html", "category_m_a_map_view_07_snapshot_08" ],
    [ "MAMapView(LocationOption)", "category_m_a_map_view_07_location_option_08.html", "category_m_a_map_view_07_location_option_08" ],
    [ "<MAMapViewDelegate>", "protocol_m_a_map_view_delegate-p.html", "protocol_m_a_map_view_delegate-p" ],
    [ "MAMapLanguage", "_m_a_map_view_8h.html#a8d56071bc6abb3d2efb9a263f6738485", [
      [ "MAMapLanguageZhCN", "_m_a_map_view_8h.html#a8d56071bc6abb3d2efb9a263f6738485a23a8076672f94846d655abcdc1a73bd0", null ],
      [ "MAMapLanguageEn", "_m_a_map_view_8h.html#a8d56071bc6abb3d2efb9a263f6738485a9eb8b82f11e213fb719d703afb6d463e", null ]
    ] ],
    [ "MAMapType", "_m_a_map_view_8h.html#a5d886bab9d38be604fbe32a4fe994ed3", [
      [ "MAMapTypeStandard", "_m_a_map_view_8h.html#a5d886bab9d38be604fbe32a4fe994ed3ac9fc8b6df95bc097f840982089d65012", null ],
      [ "MAMapTypeSatellite", "_m_a_map_view_8h.html#a5d886bab9d38be604fbe32a4fe994ed3a48b5d61fb470cd3d9bc1fbd359e56266", null ]
    ] ],
    [ "MAUserTrackingMode", "_m_a_map_view_8h.html#abd5906b49b1c430e6b3b5cc6b66e0fa0", [
      [ "MAUserTrackingModeNone", "_m_a_map_view_8h.html#abd5906b49b1c430e6b3b5cc6b66e0fa0a68b5b4750136070eaf6efb2453697510", null ],
      [ "MAUserTrackingModeFollow", "_m_a_map_view_8h.html#abd5906b49b1c430e6b3b5cc6b66e0fa0a17d6501dc4d576b5f734fd299311d686", null ],
      [ "MAUserTrackingModeFollowWithHeading", "_m_a_map_view_8h.html#abd5906b49b1c430e6b3b5cc6b66e0fa0a7e87328dbe4daf4572a9f418c3c43250", null ]
    ] ]
];
//
//  AMEntrySelect2Controller.h
//  MAMapKit_2D_Demo
//
//  Created by shaobin on 16/8/16.
//  Copyright © 2016年 Autonavi. All rights reserved.
//

#import "AMBaseEntrySelectController.h"

@interface AMEntrySelect2Controller : AMBaseEntrySelectController

@end

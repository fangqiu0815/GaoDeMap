//
//  RailwayStationDetailViewController.h
//  officialDemo2D
//
//  Created by xiaoming han on 16/8/1.
//  Copyright © 2016年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapSearchKit/AMapSearchKit.h>

@interface RailwayStationDetailViewController : UIViewController

@property (nonatomic, strong) AMapRailwayStation *railwayStation;

@end

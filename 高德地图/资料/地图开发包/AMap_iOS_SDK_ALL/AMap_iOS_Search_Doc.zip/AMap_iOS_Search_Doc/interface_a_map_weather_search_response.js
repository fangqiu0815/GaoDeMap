var interface_a_map_weather_search_response =
[
    [ "forecasts", "interface_a_map_weather_search_response.html#a126bcd8a80de70d763a04c09a478520d", null ],
    [ "lives", "interface_a_map_weather_search_response.html#a88cb8210fe6951634d35dda389be0cd1", null ]
];
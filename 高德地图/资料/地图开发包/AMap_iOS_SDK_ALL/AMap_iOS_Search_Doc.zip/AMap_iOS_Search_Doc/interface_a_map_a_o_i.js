var interface_a_map_a_o_i =
[
    [ "adcode", "interface_a_map_a_o_i.html#aebe4e3d37df4ddb8bff6824663e813c7", null ],
    [ "area", "interface_a_map_a_o_i.html#a9448dac9654fbc8d7506c762b204d5a2", null ],
    [ "location", "interface_a_map_a_o_i.html#abc139e20f068f0450decc87f56ad3a2d", null ],
    [ "name", "interface_a_map_a_o_i.html#aab631e99306f1e5a0c58c124fccfd9fa", null ],
    [ "uid", "interface_a_map_a_o_i.html#ae489c8aa0595a15ed1e0d5d266b1593e", null ]
];
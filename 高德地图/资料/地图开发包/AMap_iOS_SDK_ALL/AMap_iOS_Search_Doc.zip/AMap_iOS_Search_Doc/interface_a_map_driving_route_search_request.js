var interface_a_map_driving_route_search_request =
[
    [ "avoidpolygons", "interface_a_map_driving_route_search_request.html#a9551e18b0932c5313a7aa67a13ea781e", null ],
    [ "avoidroad", "interface_a_map_driving_route_search_request.html#a5e8bc4997f70bf76fa8583b88b5c79d4", null ],
    [ "destinationId", "interface_a_map_driving_route_search_request.html#aad26cca25a793e9fe12115177903afbb", null ],
    [ "destinationtype", "interface_a_map_driving_route_search_request.html#ae41d684354551b49d815f5f88148829a", null ],
    [ "originId", "interface_a_map_driving_route_search_request.html#ae64a1aed036cf9d5d0dde5f72022d09a", null ],
    [ "origintype", "interface_a_map_driving_route_search_request.html#a8297e628f55afefd52c626fcf58ff407", null ],
    [ "plateNumber", "interface_a_map_driving_route_search_request.html#a64a5f2d4c638af61998f7a918e61d989", null ],
    [ "plateProvince", "interface_a_map_driving_route_search_request.html#ac79a542eb6866778406a380008840ad9", null ],
    [ "requireExtension", "interface_a_map_driving_route_search_request.html#a394012274eff1d52f96bd50fd5966982", null ],
    [ "strategy", "interface_a_map_driving_route_search_request.html#a957a981c2bcc133207c6a6a82309f070", null ],
    [ "waypoints", "interface_a_map_driving_route_search_request.html#a5b804c57ad66a4d698ceff3eab289139", null ]
];
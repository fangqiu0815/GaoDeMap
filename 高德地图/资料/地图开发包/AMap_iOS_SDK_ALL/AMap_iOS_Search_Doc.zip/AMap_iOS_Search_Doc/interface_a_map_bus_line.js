var interface_a_map_bus_line =
[
    [ "arrivalStop", "interface_a_map_bus_line.html#aaab507fc57b0d06c398085425c691404", null ],
    [ "basicPrice", "interface_a_map_bus_line.html#aa441df17d189a4a69251070878b3505a", null ],
    [ "bounds", "interface_a_map_bus_line.html#a379319a915a579e7b3b4e86652e14ced", null ],
    [ "busStops", "interface_a_map_bus_line.html#ae0cb90c34a6d4b918aba8ac37b50640b", null ],
    [ "citycode", "interface_a_map_bus_line.html#ab8c0cfa47778f2930ab16eb1039a1e93", null ],
    [ "company", "interface_a_map_bus_line.html#a4aa2168724231b743769f6b3f8e45760", null ],
    [ "departureStop", "interface_a_map_bus_line.html#a832213d6622f606e78d6970d1ba7d3dd", null ],
    [ "distance", "interface_a_map_bus_line.html#a5c2990a2e699ca4de49e2fdb330f5797", null ],
    [ "duration", "interface_a_map_bus_line.html#aef9fd26fcaad07467799cdab0ead7509", null ],
    [ "endStop", "interface_a_map_bus_line.html#a0ebe33512cdae6cd4a0d803689d6f8ac", null ],
    [ "endTime", "interface_a_map_bus_line.html#afc10a86f73b54ce5ab9fded25ea90ba5", null ],
    [ "location", "interface_a_map_bus_line.html#ae7d669a83ceae9dcfe8db011a698daf8", null ],
    [ "name", "interface_a_map_bus_line.html#a87e73e61ec5ff0b11bfd100774c61550", null ],
    [ "polyline", "interface_a_map_bus_line.html#a1f968c896c8249da93062fe684187e2c", null ],
    [ "startStop", "interface_a_map_bus_line.html#a1480a372617bda609f6e3f75c596cb9c", null ],
    [ "startTime", "interface_a_map_bus_line.html#a438ddb2f8e8364cfa262d977ac79ec3a", null ],
    [ "totalPrice", "interface_a_map_bus_line.html#a628df174ae85b9d1e13b6741782fcf17", null ],
    [ "type", "interface_a_map_bus_line.html#acc74d906de687d8e96c51a6189a7949c", null ],
    [ "uid", "interface_a_map_bus_line.html#aac351ce7c292ac9df46f9676b428ea3d", null ],
    [ "viaBusStops", "interface_a_map_bus_line.html#acf5a13c75d05ce2056a005dd81285055", null ]
];
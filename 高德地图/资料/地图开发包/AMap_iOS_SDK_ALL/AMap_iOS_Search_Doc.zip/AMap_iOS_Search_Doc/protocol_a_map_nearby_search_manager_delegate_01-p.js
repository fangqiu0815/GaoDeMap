var protocol_a_map_nearby_search_manager_delegate_01_p =
[
    [ "nearbyInfoForUploading:", "protocol_a_map_nearby_search_manager_delegate_01-p.html#ab6fe153fcdf27be5d746dfc36a84b747", null ],
    [ "onNearbyInfoUploadedWithError:", "protocol_a_map_nearby_search_manager_delegate_01-p.html#a21e6339dc395d470a8133fe9e7319ef8", null ],
    [ "onUserInfoClearedWithError:", "protocol_a_map_nearby_search_manager_delegate_01-p.html#a4081acfca2c8434d440328fa0ab09102", null ]
];
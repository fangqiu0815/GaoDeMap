var interface_a_map_cloud_p_o_i_polygon_search_request =
[
    [ "keywords", "interface_a_map_cloud_p_o_i_polygon_search_request.html#a6a6d15cf5803814b75f328d5303eef1a", null ],
    [ "polygon", "interface_a_map_cloud_p_o_i_polygon_search_request.html#a2fd9a021646272362fe4da64013c6b00", null ]
];
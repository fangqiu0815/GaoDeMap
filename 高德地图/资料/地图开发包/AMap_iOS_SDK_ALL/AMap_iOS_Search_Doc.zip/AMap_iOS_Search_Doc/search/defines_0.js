var searchData=
[
  ['amapsearchminrequiredfoundationversion',['AMapSearchMinRequiredFoundationVersion',['../_a_map_search_version_8h.html#abbe9fbc6f627de58b3b9bb43fc0876b9',1,'AMapSearchVersion.h']]],
  ['amapsearchversionnumber',['AMapSearchVersionNumber',['../_a_map_search_version_8h.html#a4720ef1eec9516b2414a2b0f83ccca71',1,'AMapSearchVersion.h']]]
];

var searchData=
[
  ['sharedinstance',['sharedInstance',['../interface_a_map_nearby_search_manager.html#a2f681a17e695a99543ddf9277bf5c211',1,'AMapNearbySearchManager']]],
  ['startautouploadnearbyinfo',['startAutoUploadNearbyInfo',['../interface_a_map_nearby_search_manager.html#afdc7feaed0e90772679f7cf6be2c897b',1,'AMapNearbySearchManager']]],
  ['stopautouploadnearbyinfo',['stopAutoUploadNearbyInfo',['../interface_a_map_nearby_search_manager.html#a516dde138921355fd5accf5f6de96fb0',1,'AMapNearbySearchManager']]]
];

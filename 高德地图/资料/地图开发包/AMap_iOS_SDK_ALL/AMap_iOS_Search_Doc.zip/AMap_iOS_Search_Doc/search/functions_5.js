var searchData=
[
  ['nearbyinfoforuploading_3a',['nearbyInfoForUploading:',['../protocol_a_map_nearby_search_manager_delegate_01-p.html#ab6fe153fcdf27be5d746dfc36a84b747',1,'AMapNearbySearchManagerDelegate -p']]]
];

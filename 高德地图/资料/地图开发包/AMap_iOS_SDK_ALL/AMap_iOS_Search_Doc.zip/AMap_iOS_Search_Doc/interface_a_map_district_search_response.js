var interface_a_map_district_search_response =
[
    [ "count", "interface_a_map_district_search_response.html#a9a4c3d11af10a7ee8841af2b7ab46b52", null ],
    [ "districts", "interface_a_map_district_search_response.html#ae0b77f8eebefd28e02217b4a4d784f74", null ]
];
var interface_a_map_cloud_image =
[
    [ "preurl", "interface_a_map_cloud_image.html#a1a9d6961574f51ed51cd800ac55353b5", null ],
    [ "uid", "interface_a_map_cloud_image.html#aa22a513b3f20045a1c1515bd9daeed8d", null ],
    [ "url", "interface_a_map_cloud_image.html#a1eae3d067e756b02ed415e6c4aeb8701", null ]
];
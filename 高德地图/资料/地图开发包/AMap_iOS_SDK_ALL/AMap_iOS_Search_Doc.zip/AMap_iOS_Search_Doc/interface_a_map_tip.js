var interface_a_map_tip =
[
    [ "adcode", "interface_a_map_tip.html#a35cd68bcda7eb98f12de4a73b636b5b6", null ],
    [ "address", "interface_a_map_tip.html#ab31128afb3f8496c1a7fe08da418ef43", null ],
    [ "district", "interface_a_map_tip.html#ae742b4c342657bd95f6d4984bbd16529", null ],
    [ "location", "interface_a_map_tip.html#aa89cb7eec3fee7ba9e77ad4c36f13984", null ],
    [ "name", "interface_a_map_tip.html#a03d0b70029cd3fe27f0073c04d623eff", null ],
    [ "typecode", "interface_a_map_tip.html#a28f60e645d67ce06011f070f41e51521", null ],
    [ "uid", "interface_a_map_tip.html#acca377dc638cdb6ecb1294337cf92c8f", null ]
];
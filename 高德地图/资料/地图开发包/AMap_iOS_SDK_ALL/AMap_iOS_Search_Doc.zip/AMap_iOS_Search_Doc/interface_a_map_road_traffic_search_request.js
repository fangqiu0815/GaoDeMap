var interface_a_map_road_traffic_search_request =
[
    [ "adcode", "interface_a_map_road_traffic_search_request.html#a880191bc26d85be829440f37cdcc6575", null ],
    [ "requireExtension", "interface_a_map_road_traffic_search_request.html#ad05c73b3f151b1625891abc8f244cbd0", null ],
    [ "roadName", "interface_a_map_road_traffic_search_request.html#a3d7cbc99434b5e6b95d3af9a0c89e494", null ]
];
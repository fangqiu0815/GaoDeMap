var interface_a_map_p_o_i_share_search_request =
[
    [ "address", "interface_a_map_p_o_i_share_search_request.html#aeea2556aa8cc7ad0f202ded8535122db", null ],
    [ "location", "interface_a_map_p_o_i_share_search_request.html#a558bba47981b1fb45934fa80755c00a8", null ],
    [ "name", "interface_a_map_p_o_i_share_search_request.html#ac0901aeae4875e8f4daae17ccbe6afeb", null ],
    [ "uid", "interface_a_map_p_o_i_share_search_request.html#a963a557980620f8d6d7980261406c3ec", null ]
];
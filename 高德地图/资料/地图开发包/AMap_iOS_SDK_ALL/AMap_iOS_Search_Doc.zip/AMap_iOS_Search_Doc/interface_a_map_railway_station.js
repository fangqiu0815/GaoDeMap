var interface_a_map_railway_station =
[
    [ "adcode", "interface_a_map_railway_station.html#a01407c54a46de62324766853867b1768", null ],
    [ "isEnd", "interface_a_map_railway_station.html#aa2a933f0be5f350cae141e5a26896865", null ],
    [ "isStart", "interface_a_map_railway_station.html#acdc87609e6a433f5e20c98f6c5c408d4", null ],
    [ "location", "interface_a_map_railway_station.html#aee6827b94a62604f2e9056f0b34ad7f0", null ],
    [ "name", "interface_a_map_railway_station.html#a20080221c2c2d824e71d5b17275caeca", null ],
    [ "time", "interface_a_map_railway_station.html#a043a081d1ac963703763b1bd75166f02", null ],
    [ "uid", "interface_a_map_railway_station.html#ac4a7c23afd1a08fde3cef1f11231b1ff", null ],
    [ "wait", "interface_a_map_railway_station.html#a617aace7884a90f515f7b8001e86b269", null ]
];
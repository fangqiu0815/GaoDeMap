var interface_a_map_geo_polygon =
[
    [ "points", "interface_a_map_geo_polygon.html#a8241e54d524af512847949adce8954de", null ]
];
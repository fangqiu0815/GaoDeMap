var interface_a_map_geocode_search_response =
[
    [ "count", "interface_a_map_geocode_search_response.html#a99eced1a4d58bff33e97a75de4b182dd", null ],
    [ "geocodes", "interface_a_map_geocode_search_response.html#abd37e9742bde02782348029b5596a3ad", null ]
];
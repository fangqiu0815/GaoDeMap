var interface_a_map_traffic_evaluation =
[
    [ "blocked", "interface_a_map_traffic_evaluation.html#a40082a91783ab2628c55c6445a0846b9", null ],
    [ "congested", "interface_a_map_traffic_evaluation.html#ae3e02123afa0fe661a8d07699bb579f9", null ],
    [ "evaluationDescription", "interface_a_map_traffic_evaluation.html#a988ab64788bd0237db7cddd6e9707378", null ],
    [ "expedite", "interface_a_map_traffic_evaluation.html#a2e35397ee75b14c0d4c3c70a6ff92619", null ],
    [ "status", "interface_a_map_traffic_evaluation.html#a10f26bc7848c9dac84d65387b319ddba", null ],
    [ "unknown", "interface_a_map_traffic_evaluation.html#a6ad0925d91a75ee67ec7901fa7ae880b", null ]
];
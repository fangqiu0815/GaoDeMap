var interface_a_map_walking =
[
    [ "destination", "interface_a_map_walking.html#a1aaf97f3c93024122f24f5622188d6c1", null ],
    [ "distance", "interface_a_map_walking.html#af38a986d0a326217d865520bec629e86", null ],
    [ "duration", "interface_a_map_walking.html#a8d9c6127c8fcdcf62e3ffdf032e747da", null ],
    [ "origin", "interface_a_map_walking.html#a9195d4a71f91efe4bfc48a2e3e378797", null ],
    [ "steps", "interface_a_map_walking.html#a28a3017284881b98b50be02f351f7a58", null ]
];
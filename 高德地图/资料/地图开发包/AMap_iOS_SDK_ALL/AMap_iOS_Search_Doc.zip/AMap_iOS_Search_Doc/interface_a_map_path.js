var interface_a_map_path =
[
    [ "distance", "interface_a_map_path.html#ab89fcbc7529a3f75b4d0348349fea3eb", null ],
    [ "duration", "interface_a_map_path.html#a88c277335cb074b71eb8a081297ef2bf", null ],
    [ "restriction", "interface_a_map_path.html#a9daa4393a7ce21660c2036484195f86c", null ],
    [ "steps", "interface_a_map_path.html#a66fda4cf6e35a3f8353326c0972ef08b", null ],
    [ "strategy", "interface_a_map_path.html#a83851216ab7b03e9dcbb995f5a687bed", null ],
    [ "tollDistance", "interface_a_map_path.html#aeb80fbd04a40a71e8ec5270f59e836ca", null ],
    [ "tolls", "interface_a_map_path.html#a342a3b066ddaf9537dff5adf99f262c6", null ],
    [ "totalTrafficLights", "interface_a_map_path.html#a2486fb84cb060492411c8a2a18e7a039", null ]
];
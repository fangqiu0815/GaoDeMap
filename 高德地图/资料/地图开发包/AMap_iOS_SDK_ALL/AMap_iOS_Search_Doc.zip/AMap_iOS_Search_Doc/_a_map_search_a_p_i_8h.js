var _a_map_search_a_p_i_8h =
[
    [ "AMapSearchAPI", "interface_a_map_search_a_p_i.html", "interface_a_map_search_a_p_i" ],
    [ "<AMapSearchDelegate>", "protocol_a_map_search_delegate-p.html", "protocol_a_map_search_delegate-p" ],
    [ "AMapSearchLanguage", "_a_map_search_a_p_i_8h.html#a03d3a5375bdd76a47fca3d975b55b423", [
      [ "AMapSearchLanguageZhCN", "_a_map_search_a_p_i_8h.html#a03d3a5375bdd76a47fca3d975b55b423a7c739de0acd06a9783876836712c263c", null ],
      [ "AMapSearchLanguageEn", "_a_map_search_a_p_i_8h.html#a03d3a5375bdd76a47fca3d975b55b423ace4590a6019992131db27b9b8ba1411d", null ]
    ] ]
];
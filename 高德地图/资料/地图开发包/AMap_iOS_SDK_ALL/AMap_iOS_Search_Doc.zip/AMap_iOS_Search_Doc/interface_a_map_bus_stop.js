var interface_a_map_bus_stop =
[
    [ "adcode", "interface_a_map_bus_stop.html#a754bb1640b5a573487518dc7b511760c", null ],
    [ "buslines", "interface_a_map_bus_stop.html#a27a29a1d26cea3a71f05234d98cff7a3", null ],
    [ "citycode", "interface_a_map_bus_stop.html#af5eb30491a2ca320aa491e2b1fd529a4", null ],
    [ "location", "interface_a_map_bus_stop.html#aef22ce2ec93190b951b907c74efb3dd4", null ],
    [ "name", "interface_a_map_bus_stop.html#aafdde7ecba5a9cfd718c22dceb2c7f8d", null ],
    [ "sequence", "interface_a_map_bus_stop.html#ab91b01765a9761e2b732440985e0570a", null ],
    [ "uid", "interface_a_map_bus_stop.html#a6589bffca062864784e0685e12be1f8f", null ]
];
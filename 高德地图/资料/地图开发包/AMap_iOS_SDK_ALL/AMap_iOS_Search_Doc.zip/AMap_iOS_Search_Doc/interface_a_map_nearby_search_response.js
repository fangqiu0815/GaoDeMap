var interface_a_map_nearby_search_response =
[
    [ "count", "interface_a_map_nearby_search_response.html#a5b14b3b64153d009786aee4c1a17d1e1", null ],
    [ "infos", "interface_a_map_nearby_search_response.html#a5a36e9b0e006157a2f84d73b447d752b", null ]
];
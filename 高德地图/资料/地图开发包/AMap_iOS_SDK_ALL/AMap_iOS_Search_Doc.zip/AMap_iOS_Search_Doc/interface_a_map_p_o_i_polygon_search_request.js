var interface_a_map_p_o_i_polygon_search_request =
[
    [ "keywords", "interface_a_map_p_o_i_polygon_search_request.html#a0dfa6a8be87d78a5a61924d8fb2c6deb", null ],
    [ "polygon", "interface_a_map_p_o_i_polygon_search_request.html#a58f035c608d92d0524e662f530c9c511", null ]
];
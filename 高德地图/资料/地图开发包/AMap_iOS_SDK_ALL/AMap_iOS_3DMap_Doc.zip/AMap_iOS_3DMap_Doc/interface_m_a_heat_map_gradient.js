var interface_m_a_heat_map_gradient =
[
    [ "initWithColor:andWithStartPoints:", "interface_m_a_heat_map_gradient.html#ab03da4c974878dec13970de68dcbd71e", null ],
    [ "colors", "interface_m_a_heat_map_gradient.html#a75cbc8097d1895d52fdc64c8ee26108b", null ],
    [ "startPoints", "interface_m_a_heat_map_gradient.html#ab3652ed48b32b86cbae4838f394d3f76", null ]
];
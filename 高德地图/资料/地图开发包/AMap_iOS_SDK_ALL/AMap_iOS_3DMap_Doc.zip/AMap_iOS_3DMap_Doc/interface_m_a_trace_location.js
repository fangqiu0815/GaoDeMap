var interface_m_a_trace_location =
[
    [ "angle", "interface_m_a_trace_location.html#ab72b914767a1bd5a3fcc7cb72b7c8c30", null ],
    [ "loc", "interface_m_a_trace_location.html#ad530e1b4ac4f8ef220c10d338718fdc7", null ],
    [ "speed", "interface_m_a_trace_location.html#aa3df3c2d09c918e9a91c21a9f0c96a6c", null ],
    [ "time", "interface_m_a_trace_location.html#ad392d2911182eaa33cbd9b67272117bc", null ]
];
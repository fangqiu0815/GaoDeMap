var interface_m_a_user_location =
[
    [ "heading", "interface_m_a_user_location.html#a920153a88874290601bc43ff9a3ab310", null ],
    [ "location", "interface_m_a_user_location.html#a6115765b71cc695a9e716d2911a17cef", null ],
    [ "updating", "interface_m_a_user_location.html#af8ed215143761b9811234196549da8f6", null ]
];
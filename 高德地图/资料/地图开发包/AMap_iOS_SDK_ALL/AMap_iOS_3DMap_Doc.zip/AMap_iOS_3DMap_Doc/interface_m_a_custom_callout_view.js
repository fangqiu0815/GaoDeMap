var interface_m_a_custom_callout_view =
[
    [ "initWithCustomView:", "interface_m_a_custom_callout_view.html#abcbc76b7f4038e6bb303bf806d8e487c", null ],
    [ "customView", "interface_m_a_custom_callout_view.html#ad6fc70ea9340730738fc2c7944623986", null ],
    [ "userData", "interface_m_a_custom_callout_view.html#acc497ca0b0ac25474a12b38717907fa4", null ]
];
var searchData=
[
  ['boundingmaprect',['boundingMapRect',['../interface_m_a_circle.html#a472ef3ad80d86415b79c210d88e0816b',1,'MACircle::boundingMapRect()'],['../protocol_m_a_overlay_01-p.html#a65b7395a389e6fc441512f78a1ab0ebd',1,'MAOverlay -p::boundingMapRect()'],['../interface_m_a_tile_overlay.html#a769d8fc99b4862bc8c1a0991d096f914',1,'MATileOverlay::boundingMapRect()']]],
  ['bounds',['bounds',['../interface_m_a_ground_overlay.html#aedb61b591a8c4f53590df4611cd96881',1,'MAGroundOverlay']]],
  ['buildingtype',['buildingType',['../interface_m_a_indoor_info.html#ac1f460895a78752035c382fe139c9d75',1,'MAIndoorInfo']]]
];

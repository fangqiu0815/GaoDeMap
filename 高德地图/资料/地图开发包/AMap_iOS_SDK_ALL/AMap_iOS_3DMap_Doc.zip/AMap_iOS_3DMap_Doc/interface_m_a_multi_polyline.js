var interface_m_a_multi_polyline =
[
    [ "setPolylineWithCoordinates:count:drawStyleIndexes:", "interface_m_a_multi_polyline.html#a99675f82025b488599ebf73f524837dc", null ],
    [ "setPolylineWithPoints:count:drawStyleIndexes:", "interface_m_a_multi_polyline.html#ab5bbfeaf8b71b84bb563f9d7f66edd6e", null ],
    [ "drawStyleIndexes", "interface_m_a_multi_polyline.html#aa3dfe851cf8cd8e80d2eed8f652b0e23", null ]
];
var interface_m_a_shape =
[
    [ "_subtitle", "interface_m_a_shape.html#acb42d662ac29dc6c5e621f1a9a519c8e", null ],
    [ "_title", "interface_m_a_shape.html#a28d5c613a2d84b820ea517994b93846a", null ],
    [ "subtitle", "interface_m_a_shape.html#a8c593bba5991751c6ad08c66204b1c54", null ],
    [ "title", "interface_m_a_shape.html#a3c4e1927b0ce84ad0df66bdfbcb07468", null ]
];
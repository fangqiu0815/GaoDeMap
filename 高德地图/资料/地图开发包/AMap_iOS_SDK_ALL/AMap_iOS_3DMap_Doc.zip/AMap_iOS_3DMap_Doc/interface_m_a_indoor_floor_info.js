var interface_m_a_indoor_floor_info =
[
    [ "floorIndex", "interface_m_a_indoor_floor_info.html#a0850cb5653ca9b5e4522ba046560485d", null ],
    [ "floorName", "interface_m_a_indoor_floor_info.html#a6a9a82a76c367b6170b5516176b711b6", null ],
    [ "floorNona", "interface_m_a_indoor_floor_info.html#a8e8d66a9d719bb2c1d1d4e37de0b34e8", null ],
    [ "isPark", "interface_m_a_indoor_floor_info.html#ad8e2e9a22dd60819e5f2cbc0ce045831", null ]
];
var protocol_m_a_multi_point_overlay_renderer_delegate_01_p =
[
    [ "multiPointOverlayRenderer:didItemTapped:", "protocol_m_a_multi_point_overlay_renderer_delegate_01-p.html#ac9b87d5a0ecb76eb15cd5d8a44bf4feb", null ]
];
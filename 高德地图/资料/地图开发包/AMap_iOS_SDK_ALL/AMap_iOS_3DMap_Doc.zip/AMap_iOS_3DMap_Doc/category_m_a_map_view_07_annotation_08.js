var category_m_a_map_view_07_annotation_08 =
[
    [ "addAnnotation:", "category_m_a_map_view_07_annotation_08.html#a7b86714620e386feea317c286d0952d7", null ],
    [ "addAnnotations:", "category_m_a_map_view_07_annotation_08.html#a72b23f7ff31b0a5804562eb13e056eed", null ],
    [ "annotationsInMapRect:", "category_m_a_map_view_07_annotation_08.html#af5f8591ea03619b15a1a98431a2c08f6", null ],
    [ "dequeueReusableAnnotationViewWithIdentifier:", "category_m_a_map_view_07_annotation_08.html#a8cef2b9f402a7d8d571350f55ab1c88f", null ],
    [ "deselectAnnotation:animated:", "category_m_a_map_view_07_annotation_08.html#af02a2ffa63fb7f3d0e018ee22c88d0e5", null ],
    [ "removeAnnotation:", "category_m_a_map_view_07_annotation_08.html#a3c9b361318963396e36982a024884daf", null ],
    [ "removeAnnotations:", "category_m_a_map_view_07_annotation_08.html#aa1a5b71f51d6197f97a596f59779db06", null ],
    [ "selectAnnotation:animated:", "category_m_a_map_view_07_annotation_08.html#a596c6e67224cfc67a5d100e4eee325ff", null ],
    [ "showAnnotations:animated:", "category_m_a_map_view_07_annotation_08.html#af416ac86fae73fda38570f4174e57842", null ],
    [ "showAnnotations:edgePadding:animated:", "category_m_a_map_view_07_annotation_08.html#a01e04e2fcabed4cf0889354c38630a39", null ],
    [ "viewForAnnotation:", "category_m_a_map_view_07_annotation_08.html#a9714c9221717ec4d861c64df69e8983c", null ],
    [ "allowsAnnotationViewSorting", "category_m_a_map_view_07_annotation_08.html#a863e4f55f8e67395c195c82505f80fe9", null ],
    [ "annotations", "category_m_a_map_view_07_annotation_08.html#a975796c394530bdb4b0662ccecbd914d", null ],
    [ "annotationVisibleRect", "category_m_a_map_view_07_annotation_08.html#ad5538e1ef2f43ffbdce324c99edb7c3a", null ],
    [ "selectedAnnotations", "category_m_a_map_view_07_annotation_08.html#a9c009d6aacafb19656d04ed4e0fed6b1", null ]
];
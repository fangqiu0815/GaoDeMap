var interface_m_a_offline_item =
[
    [ "adcode", "interface_m_a_offline_item.html#a27adda50b13dd3d7e545f4fe5dd98f50", null ],
    [ "downloadedSize", "interface_m_a_offline_item.html#a26d8fcbec191f37dec8f0005bd1a0973", null ],
    [ "itemStatus", "interface_m_a_offline_item.html#a8b78077ab427a334bdb7bd1a13cebeb4", null ],
    [ "jianpin", "interface_m_a_offline_item.html#a5c00d89b23bc8763a6bbe8285c69b932", null ],
    [ "name", "interface_m_a_offline_item.html#a1a791589f9ecffcece6455bd089246a9", null ],
    [ "pinyin", "interface_m_a_offline_item.html#a240594f27eb426b7067cc46581dde2dd", null ],
    [ "size", "interface_m_a_offline_item.html#aba766d4d77ae0a59ac289f6c5db4f229", null ]
];
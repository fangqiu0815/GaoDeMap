var interface_m_a_offline_map =
[
    [ "cancelAll", "interface_m_a_offline_map.html#ae48e7a927a1cd4a69427029f5ac582a1", null ],
    [ "checkNewestVersion:", "interface_m_a_offline_map.html#a031cb6088211f9950e3fde94cae43846", null ],
    [ "clearDisk", "interface_m_a_offline_map.html#a4c0b8b8f4f4135ee7ecab32341238858", null ],
    [ "deleteItem:", "interface_m_a_offline_map.html#aee867a56bd651d7b5b8b0cd96720c921", null ],
    [ "downloadCity:downloadBlock:", "interface_m_a_offline_map.html#a4c5a91d43888130250ab57cd377c7f68", null ],
    [ "downloadCity:shouldContinueWhenAppEntersBackground:downloadBlock:", "interface_m_a_offline_map.html#a74002c4eb9a6022903261ddf56039f1c", null ],
    [ "downloadItem:shouldContinueWhenAppEntersBackground:downloadBlock:", "interface_m_a_offline_map.html#aa0880fbb5c3bded229564ad32239ac5a", null ],
    [ "isDownloadingForCity:", "interface_m_a_offline_map.html#add17492e861f9ffe3471e4b80eca5eb9", null ],
    [ "isDownloadingForItem:", "interface_m_a_offline_map.html#affabdc820c2af23d00292df72499dbbe", null ],
    [ "pause:", "interface_m_a_offline_map.html#a8d8b158cb05002145a6d4edb08d7a385", null ],
    [ "pauseItem:", "interface_m_a_offline_map.html#a7b3214019b1fe317d19412b74032f007", null ],
    [ "setupWithCompletionBlock:", "interface_m_a_offline_map.html#a923ba5ece07d005f3372d0a9c813b6ce", null ],
    [ "cities", "interface_m_a_offline_map.html#a3d72f9743f4e6381edf5dc8934fbfb03", null ],
    [ "municipalities", "interface_m_a_offline_map.html#aa17eaf2ffe4d279dd8f4812f53ce9c03", null ],
    [ "nationWide", "interface_m_a_offline_map.html#a824b2b4585aea2cc8d108252e7ed6771", null ],
    [ "offlineCities", "interface_m_a_offline_map.html#af9fee89e41d51c0031bfb2be49f585ab", null ],
    [ "provinces", "interface_m_a_offline_map.html#ad4877d9f76d5b83930a9984e5cf94e87", null ],
    [ "version", "interface_m_a_offline_map.html#a474670a85dc7e423e282566a5f5df9f2", null ]
];
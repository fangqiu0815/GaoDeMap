//
//  IndoorMapViewController.h
//  MAMapKit_3D_Demo
//
//  Created by shaobin on 2017/6/27.
//  Copyright © 2017年 Autonavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndoorMapViewController : UIViewController

@end
